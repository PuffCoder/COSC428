# Plates Detector > 2023-04-25 2:06pm
https://universe.roboflow.com/object-detection/plates-detector

Provided by a Roboflow user
License: CC BY 4.0

